# StudentAttendanceCheck
A student attendance check-in app for Attendance monitoring system

This project is part of my "Phone app for attendance monitoring system" project. The system consists of three part
1. Android App for student to check-in to the class (this repo)
2. Android App for teacher to monitor student's attendance (https://github.com/landtanin/TeacherAttendanceMonitoring)
3. MySQL database PHP Server (https://github.com/landtanin/MySQL-database-for-Attendance-monitoring-system/tree/master)

## Getting Started
Use these username and password informations if you want to play around with the app
1. user: johndoe@johndoe.com
   pass: johndoe

2. user: harrypotter@harrypotter.com
   pass: harrypotter

3. user: rowanatkinson@rowanatkinson.com
   pass: rowanatkinson

4. user: tonystark@tonystark.com
   pass: tonystark


 
